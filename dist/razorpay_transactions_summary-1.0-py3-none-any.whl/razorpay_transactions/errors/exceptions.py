class PaymentReportBaseException(Exception):
    pass
